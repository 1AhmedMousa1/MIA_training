#include <stdio.h>
#include <stdlib.h>

int main()
{
    int num1;

    printf("enter your number: \n");

    scanf("%d", &num1);
    return 0;
}
